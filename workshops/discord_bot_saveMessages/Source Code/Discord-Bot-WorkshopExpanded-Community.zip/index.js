const Discord = require('discord.js')
const client = new Discord.Client()
const fs = require("fs");
client.msgs = require("./msgs.json");
prefix = "!"

client.once('ready', () => {
    console.log('Ready!')
})

client.on('message', (message) => {
if (message.content.startsWith(`${prefix}write `))
{
  var tempSplits = message.content.split(" ", 2);
  var keyVal = tempSplits[1];
  var messageVal = message.content.slice(tempSplits[0].length + tempSplits[1].length + 2);
       
  if (client.msgs["Community"] == undefined)
  {
    client.msgs ["Community"] ={}
  }
  client.msgs["Community"][keyVal] = messageVal

  fs.writeFile ("./msgs.json", JSON.stringify (client.msgs, null, 4), err =>{
    if (err) throw err;
    message.channel.send("message written");
    })
}

if (message.content.startsWith(`${prefix}get `))
{
  let getMessage = message.content.slice(5);
  let _msg = client.msgs["Community"][getMessage];
  message.channel.send(_msg);
}

if (message.content.startsWith(`${prefix}delete `))
{
  let getMessage = message.content.slice(8);

  delete client.msgs["Community"][getMessage];

  fs.writeFileSync("./msgs.json", JSON.stringify(client.msgs));

  message.channel.send(getMessage + " has been deleted.");
}

if (message.content == (`${prefix}list`))
{
  var messageList = "";

  for(var key in client.msgs["Community"])
  {
    messageList += (key+", ");
  }
  
  message.channel.send(messageList);
}

if (message.content.startsWith(`${prefix}communitywrite `))
{
  var tempSplits = message.content.split(" ", 2);
  var keyVal = tempSplits[1];
  var messageVal = message.content.slice(tempSplits[0].length + tempSplits[1].length + 2);
       
  if (client.msgs["Community"] == undefined)
  {
    client.msgs ["Community"] ={}
  }
  client.msgs["Community"][keyVal] = messageVal

  fs.writeFile ("./msgs.json", JSON.stringify (client.msgs, null, 4), err =>{
    if (err) throw err;
    message.channel.send("message written");
    })
}

if (message.content.startsWith(`${prefix}communityget `))
{
  let getMessage = message.content.slice(14);
  let _msg = client.msgs["Community"][getMessage];
  message.channel.send(_msg);
}

if (message.content == (`${prefix}communitylist`))
{
  var messageList = "";

  for(var key in client.msgs["Community"])
  {
    messageList += (key+", ");
  }
  
  message.channel.send(messageList);
}

if (message.content == (`${prefix}help`))
{
  message.channel.send("To send a message do: !write {messageKey} {message}\nTo get a message do: !get {messageKey}\nTo delete a message !delete {messageKey}\nTo view your    messages !list\n Put the word community in front of the first three commands get access the community versions (communitywrite, communityget, communitylist)");
}

})

client.login('Insert Bot Token Here')