const Discord = require('discord.js')
const client = new Discord.Client()
const fs = require("fs");
client.msgs = require("./msgs.json");
prefix = "!"
messageAmount = 5

client.once('ready', () => {
    console.log('Ready!')
})

client.on('message', (message) => {
if (message.content.startsWith(`${prefix}write `))
{
  var tempSplits = message.content.split(" ", 2);
  var keyVal = tempSplits[1];
  var messageVal = message.content.slice(tempSplits[0].length + tempSplits[1].length + 2);
       
  if (client.msgs[message.author.id] == undefined)
  {
    client.msgs [message.author.id] ={}
  }
  tempMessageAmt = 0
  for(var key in client.msgs[message.author.id])
  {
    tempMessageAmt++
  }

  if (tempMessageAmt < messageAmount)
  {
    client.msgs[message.author.id][keyVal] = messageVal
  

    fs.writeFile ("./msgs.json", JSON.stringify (client.msgs, null, 4), err =>{
      if (err) throw err;
      message.channel.send("message written");
      })
  }
  else
  {
    message.channel.send("You message amount exceeds the " + messageAmount + " message limit.")
  }
}

if (message.content.startsWith(`${prefix}get `))
{
  let getMessage = message.content.slice(5);
  let _msg = client.msgs[message.author.id][getMessage];
  message.channel.send(_msg);
}

if (message.content.startsWith(`${prefix}delete `))
{
  let getMessage = message.content.slice(8);

  delete client.msgs[message.author.id][getMessage];

  fs.writeFileSync("./msgs.json", JSON.stringify(client.msgs));

  message.channel.send(getMessage + " has been deleted.");
}

if (message.content == (`${prefix}list`))
{
  var messageList = "";

  for(var key in client.msgs[message.author.id])
  {
    messageList += (key+", ");
  }
  
  message.channel.send(messageList);
}

if (message.content == (`${prefix}help`))
{
  message.channel.send("To send a message do: !write {messageKey} {message}\nTo get a message do: !get {messageKey}\nTo delete a message !delete {messageKey}\nTo view your messages !list");
}

})

client.login('Insert Bot Token Here')